/**
 * Clase que pertenece al controller
 */
package co.edu.unbosque.controller;

/**
 * Clase AplMain para ejecutar el programa
 * @author Katherine Patino
 * @author Daniela Pineros
 *
 */
public class AplMain {

	/**
	 * Metodo main del proyecto.
	 * 
	 * @param args para el metodo main
	 */
	
	public static void main(String[] args) {
		
		Controller control = new Controller();

	}

}
