/**
 * 
 */
/**
 * Paquete modelo de creacion de objetos
 * @author Katherine Patino
 * @author Daniela Pineros
 *
 */
package co.edu.unbosque.model;