/**
 * Paquete de persistencia
 * @author Katherine Patino
 * @author Daniela Pineros
 */
package co.edu.unbosque.model.persistence;